package com.cg.obs.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="Request_Table")

public class RequestTable
{
	@Id
	private int custId;
	private String type;
	private int acc_id;
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAcc_id() {
		return acc_id;
	}
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	public RequestTable(int custId, String type, int acc_id) {
		super();
		this.custId = custId;
		this.type = type;
		this.acc_id = acc_id;
	}
	public RequestTable() {
		super();
	}
	@Override
	public String toString() {
		return "RequestTable [custId=" + custId + ", type=" + type
				+ ", acc_id=" + acc_id + "]";
	}
	
}
